<div class="footer">
    All rights reserved @<a href="">Company Name</a>
</div>