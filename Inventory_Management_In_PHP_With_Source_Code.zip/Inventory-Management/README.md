# Inventory-Management-Project
Creating a simple web-based inventory management system by using PHP and JavaScript.
